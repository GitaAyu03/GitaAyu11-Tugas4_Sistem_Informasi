<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="admin.css">

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="gambar/ikon.jpg" type="image/ico" />

    <title>Admin Laundry-er Gita</title>
  </head>
  <body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-info fixed-top">
        <a class="navbar-brand" href="#">SELAMAT DATANG ADMIN | <b>Laundry-er Gita</b></a>
 
          <div class="log-out">
            <button type="button" class="btn btn-light ml-auto"><a href="../index.php">Log Out</button></a>
          </div>
        </div>
    </nav>

    <div class="row no-gutters mt-5">
        <div class="col-md-2 bg-info mt-2 pr-3 pt-4">
            <ul class="nav flex-column ml-3 mb-5">
                <li class="nav-item">
                  <a class="nav-link active text-white" href="home_karyawan.php"><i class="fas fa-tachometer-alt mr-2"></i>Dashboard</a><hr class="bg-light">
                </li>
                <li class="nav-item">
                  <a class="nav-link text-white" href="data_karyawan.php"><i class="fas fa-users-cog mr-2"></i>Data Karyawan</a><hr class="bg-light">
                </li>
                <li class="nav-item">
                  <a class="nav-link text-white" href="data_customer.php"><i class="fas fa-users mr-2"></i>Data Customer</a><hr class="bg-light">
                </li>
            </ul>
        </div>
        <div class="col-md-10 p-5 pt-2">
          <h3><i class="fas fa-tachometer-alt mr-2"></i> Dashboard Karyawan </h3><hr>

          <div class="row text-white">
            <div class="card bg-info ml-5" style="width: 18rem;">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fas fa-users-cog mr-2"></i>
                </div>
                <h5 class="card-title">Data Karyawan</h5>
                <div class="display-4">10</div>
                <a href="data_karyawan.php"><p class="card-text text-white">Lihat Detail</p></a>
              </div>
            </div>

            <div class="card bg-primary ml-5" style="width: 18rem;">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fas fa-users mr-2"></i>
                </div>
                <h5 class="card-title">Data Customer</h5>
                <div class="display-4">8</div>
                <a href="data_customer.php"><p class="card-text text-white">Lihat Detail</p></a>
              </div>
            </div>

            <div class="card bg-info ml-5" style="width: 18rem;">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fas fa-file-invoice-dollar mr-2"></i>
                </div>
                <h5 class="card-title">Laporan</h5>
                <div class="display-4"></div>
                <a href="laporan.php"><p class="card-text text-white">Lihat Detail</p></a>
              </div>
            </div>
          </div>

          <div class="row mt-4">
            <div class="card ml-5 text-white text-center" style="width: 18rem;">
              <div class="card-header bg-danger display-4 pt-4 pb-4">
                <i class="fab fa-instagram"></i>
              </div>
              <div class="card-body">
                <h5 class="card-title text-danger">Instagram</h5>
                <a href="https://www.instagram.com/" class="btn btn-danger">Follow</a>
              </div>
            </div>

            <div class="card ml-5 text-white text-center" style="width: 18rem;">
              <div class="card-header bg-success display-4 pt-4 pb-4">
                <i class="fab fa-whatsapp"></i>
              </div>
              <div class="card-body">
                <h5 class="card-title text-success">Whatsapp</h5>
                <a href="https://www.whatsapp.com/" class="btn btn-success">Chat</a>
              </div>
            </div>

            <div class="card ml-5 text-white text-center" style="width: 18rem;">
              <div class="card-header bg-primary display-4 pt-4 pb-4">
                <i class="fab fa-facebook"></i>
              </div>
              <div class="card-body">
                <h5 class="card-title text-primary">Facebook</h5>
                <a href="https://www.facebook.com/" class="btn btn-primary">Add</a>
              </div>
            </div>

          </div>
        </div>
    </div>
    <!-- Akhir Navbar -->

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
    <script type="text/javascript" src="admin.js"></script>
    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
  </body>
</html>