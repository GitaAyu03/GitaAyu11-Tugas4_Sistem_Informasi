<?php
  //koneksi database
  $server = "localhost";
  $user = "root";
  $pass = "";
  $database = "dbsisteminfo";

  $koneksi = mysqli_connect($server, $user, $pass, $database)or die(mysqli_error($koneksi));

  //tombol simpan
  if(isset($_POST['bsimpan']))
  {

    //pengujian data edit atau simpan
    if($_GET['hal'] == "edit")
    {
      //data di edit
      $edit = mysqli_query($koneksi, " UPDATE tkaryawan set
                                       nik = '$_POST[tnik]',
                                       nama = '$_POST[tnama]',
                                       nomor = '$_POST[tnomor]',
                                       gender = '$_POST[tgender]'
                                      WHERE id_karyawan = '$_GET[id]'
                                     ");
      if($edit)//jika simpan sukses
      {
        echo "<script>
                alert('Edit Data Berhasil');
                document.location='data_karyawan.php';
              </script>";
      }
      else
      {
        echo "<script>
                alert('Edit Data Gagal!!');
                document.location='data_karyawan.php';
              </script>";
      }
    }else
    {
      //data simpan baru
      $simpan = mysqli_query($koneksi, "INSERT INTO tkaryawan (nik, nama, nomor, gender)
                                        VALUES ('$_POST[tnik]', 
                                                '$_POST[tnama]', 
                                                '$_POST[tnomor]', 
                                                '$_POST[tgender]')
                                        ");
      if(simpan)
      {
        echo "<script>
                alert('Simpan Data Berhasil');
                document.location='data_karyawan.php';
              </script>";
      }
      else
      {
        echo "<script>
                alert('Simpan Data Gagal!!');
                document.location='data_karyawan.php';
              </script>";
      }
    }

    
  }
  
  //pengujian edit dan hapus
  if(isset($_GET['hal']))
  {
    //tampil data edit
    if($_GET['hal'] == "edit")
    {
      $tampil = mysqli_query($koneksi, "SELECT * FROM tkaryawan WHERE id_karyawan = '$_GET[id]' ");
      $data = mysqli_fetch_array($tampil);
      if($data)
      {
        $vnik = $data['nik'];
        $vnama = $data['nama'];
        $vnomor = $data['nomor'];
        $vgender = $data['gender'];
      }
    }
    else if ($_GET['hal'] == "hapus")
    {
      //persiapan hapus data
      $hapus = mysqli_query($koneksi, "DELETE FROM tkaryawan WHERE id_karyawan = '$_GET[id]' ");
      if($hapus){
        echo "<script>
                alert('Hapus Data Berhasil');
                document.location='data_karyawan.php';
              </script>";
      }
    }
  }

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="admin.css">

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="gambar/ikon.jpg" type="image/ico" />

    <title>Admin Laundry-er Gita</title>
  </head>
  <body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-info">
      <div class="container-fluid">
        <a class="navbar-brand" href="home_karyawan.php">Dashboard</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="data_karyawan.php">Data Karyawan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="data_customer.php">Data Customer</a>
          </ul>
          <div class="log-out">
            <button type="button" class="btn btn-light"><a href="../index.php">Log Out</button></a>
          </div>
        </div>
        </div>
      </div>
    </nav>
    <!-- Akhir Navbar -->

    <div class="container">
      <h1 class="text-center"><i class="fas fa-users-cog mr-2"></i>Data Karyawan</h1> 
      <h5 class="text-center">Laundry-er Gita</h5>

      <!-- Awal form -->
      <div class="card mt-3">
        <div class="card-header bg-primary text-white">
          Form Input Data Karyawan
        </div>
        <div class="card-body">
          <form method="post" action="">
            <div class="form-group">
              <label>Nik</label>
              <input type="text" name="tnik" value="<?=@$vnik?>" class="form-control" placeholder="Masukkan Nik Anda dengan benar" required>
            </div>
            <div class="form-group">
              <label>Nama</label>
              <input type="text" name="tnama" value="<?=@$vnama?>" class="form-control" placeholder="Masukkan Nama Anda" required>
            </div>
            <div class="form-group">
              <label>Nomor</label>
              <input type="text" name="tnomor" value="<?=@$vnomor?>" class="form-control" placeholder="Masukkan Nomor Telephone Anda" required>
            </div>
            <div class="form-group">
              <label>Gender</label>
              <select class="form-control" name="tgender">
                <option value="<?=@$gender?>"><?=@$vgender?></option>
                <option value="P">P</option>
                <option value="L">L</option>
              </select>
            </div>

            <button type="submit" class="btn btn-success" name="bsimpan">Simpan</button>
            <button type="reset" class="btn btn-danger" name="breset">Kosongkan</button>

          </form>
        </div>
      </div>
    </div>

    <!-- Akhir Form -->

    <!-- Awal tabel -->
    <div class="card mt-3">
        <div class="card-header bg-success text-white">
          Daftar Data Karyawan
        </div>
        <div class="card-body">
          <table class="table table-border table-striped">
            <tr>
              <th>No.</th>
              <th>Nik</th>
              <th>Nama</th>
              <th>Nomor</th>
              <th>Gender</th>
              <th>Aksi</th>
            </tr>
            <?php
              $no = 1;
              $tampil = mysqli_query($koneksi, "SELECT * from tkaryawan order by id_karyawan desc");
              while($data = mysqli_fetch_array($tampil)) :
            ?>
            <tr>
              <td><?=$no++;?></td>
              <td><?=$data['nik']?></td>
              <td><?=$data['nama']?></td>
              <td><?=$data['nomor']?></td>
              <td><?=$data['gender']?></td>
              <td>
                <a href="data_karyawan.php?hal=edit&id=<?=$data['id_karyawan']?>" class="btn btn-warning">Edit</a>
                <a href="data_karyawan.php?hal=hapus&id=<?=$data['id_karyawan']?>" onclick="return confirm('Apakah Anda yakin Ingin menghapus data ini')" class="btn btn-danger">Hapus</a>
              </td>
            </tr>
            <?php endwhile; //penutup perulangan while ?>
          </table>
        </div>
      </div>
    </div>

    <!-- Akhir tabel -->


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
    <script type="text/javascript" src="admin.js"></script>
    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
  </body>
</html>