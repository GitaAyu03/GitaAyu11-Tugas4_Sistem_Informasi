-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 13 Jun 2021 pada 04.29
-- Versi Server: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbsisteminfo`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tkaryawan`
--

CREATE TABLE `tkaryawan` (
  `Id_karyawan` int(11) NOT NULL,
  `nik` varchar(9) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `nomor` varchar(15) NOT NULL,
  `gender` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tkaryawan`
--

INSERT INTO `tkaryawan` (`Id_karyawan`, `nik`, `nama`, `nomor`, `gender`) VALUES
(1, '15.50.002', 'Rateh Vernanda', '085766453169', 'P'),
(2, '15.50.003', 'Baim Saputra', '085645447877', 'L'),
(3, '15.50.004', 'Muhammad Arganta', '0858906755433', 'L'),
(4, '15.50.005', 'Putri Salsabila', '085775632785', 'P'),
(5, '15.50.006', 'Fahresta Ardina', '08576645980', 'P'),
(6, '15.50.007', 'Fahri Pratama', '0856454478976', 'L'),
(7, '15.50.008', 'Ardian Maharani', '0857555890334', 'P');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tkaryawan`
--
ALTER TABLE `tkaryawan`
  ADD PRIMARY KEY (`Id_karyawan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tkaryawan`
--
ALTER TABLE `tkaryawan`
  MODIFY `Id_karyawan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
