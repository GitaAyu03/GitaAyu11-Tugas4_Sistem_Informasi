<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="gambar/ikon.jpg" type="image/ico" />

    <title>Laundry-er Gita</title>
  </head>
  <body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-info">
      <div class="container-fluid">
        <a class="navbar-brand" href="home_customer.php">Home</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="paket.php">Paket Laundry</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="pemesanan.php">Pemesanan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="tentang.php">Tentang Kami</a>
            </li>
          </ul>
          <div class="log-out">
            <button type="button" class="btn btn-light"><a href="../index.php">Log Out</button></a>
          </div>
        </div>
        </div>
      </div>
    </nav>
    <!-- Akhir Navbar -->

    <div class="container">

      <h1 class="text-center">Form Pemesanan</h1>
      <h1 class="text-center">Jasa Laundry-er Gita</h1>

      <!-- Awal Form -->

      <div class="card mt-3">
        <div class="card-header bg-info text-white">
          Form Pemesanan Laundry
        </div>
        <div class="card-body">
          <form method="post" action="">
          <div class="form-grup">
              <label for="">No</label>
              <input type="text" name="tno" class="form-control" placeholder="Masukkan Nomor Handphone yang aktif" required>
            </div>
            <div class="form-grup">
              <label for="">Nama</label>
              <input type="text" name="tnama" class="form-control" placeholder="Masukkan Nama Anda" required>
            </div>
            <div class="form-grup">
              <label for="">Alamat</label>
              <textarea class="form-control" name="talamat" placeholder="Masukkan Alamat Lengkap Anda"></textarea>
            </div>
            <div class="form-grup">
              <label for="">Paket</label>
              <select class="form-control" name="tpaket">
              <option value=""></option>
              <option value="Reguler-A">Reguler-A</option>
              <option value="Reguler-B">Reguler-B</option>
              <option value="Reguler-C">Reguler-C</option>
              <option value="">--------------</option>
              <option value="Xpress-A">Xpress-A</option>
              <option value="Xpress-B">Xpress-B</option>
              <option value="Xpress-C">Xpress-C</option>
              </select>
            </div>

              <button type="submit" class="btn btn-success" name="border">Order</button>
              <button type="reset" class="btn btn-danger" name="breset">Kosongkan</button>

          </form>
        </div>
      </div>

      <!-- Akhir Form -->

    </div>

    <!-- Optional JavaScript; choose one of the two! -->
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
  </body>
</html>